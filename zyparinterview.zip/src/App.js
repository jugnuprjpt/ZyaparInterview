import './App.css';
import ZyparInterview from './Zyapar/ZyparInterview';


function App() {
  return (
    <div className="App">
      <ZyparInterview></ZyparInterview>
    </div>
  );
}

export default App;
